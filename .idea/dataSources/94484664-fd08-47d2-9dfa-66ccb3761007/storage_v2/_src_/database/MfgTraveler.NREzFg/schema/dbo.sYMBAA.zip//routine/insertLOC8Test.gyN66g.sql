-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE dbo.insertLOC8Test
	-- Add the parameters for the stored procedure here
	@timeStamp					DATETIME,
	@seid						INT,
	@GPS						varchar(1),
	@WiFi						varchar(1),
	@Proximity					varchar(1),
	@LED						varchar(3),
	@strap						varchar(1),
	@TAEvents					varchar(1),
	@testType					varchar(1),
	@internalBat				varchar(1),
	@version					nchar(10),
	@summary					varchar(200),
	@comment					varchar(200),
	@versionPass				varchar(1)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   insert into LOC8PrePostGlue ([timeStamp],[seid],[GPS],[WiFi],[Proximity],[LED],[Strap],[TAEvents],[PreOrPostGlue],[intBat],[Version],[Summary],[Comment],[versionPass])
   VALUES
   (
   	@timeStamp					,
	@seid						,
	@GPS						,
	@WiFi						,
	@Proximity					,
	@LED						,
	@strap						,
	@TAEvents					,
	@testType					,
	@internalBat				,
	@version					,
	@summary					,
	@comment					,
	@versionPass				
   )



END
GO

