-- =============================================
-- Author:		<Walker, Dominik>
-- Create date: <10/10/2017>
-- Description:	<Return records for SL8 Scrap Entry>
-- =============================================
CREATE PROCEDURE [dbo].[getSL8SC]
AS
Select top 100
s.SerialNumber,
s.Item,
c0.Description as Type,
p.Process as Operation,
p.Product,
u.Username,
s.Parts,
s.Codes,
s.Rea_Notes,
s.Res_Notes,
s.blnkcol1,
s.blnkcol2,
s.blnkcol3,
c1.Description as Process,
c2.Description as Status,
c3.Description as Error,
s.DateTime,
s.ID
From SL8Records s

--Code_Refs Joins
Left join Code_Refs c0
on s.Type = c0.Code
Left join Code_Refs c1
on s.Process = c1.Code
Left join Code_Refs c2
on s.Status = c2.Code
Left join Code_Refs c3
on s.Error = c3.Code

--Other Joins
Inner join Processes p
on s.Operation = p.ID and s.Product = p.ID
Inner join Users u
on s.Operator = u.USERID

And s.Process = 'SC' and s.Status = 'QU'

Order by s.ID ASC
GO

