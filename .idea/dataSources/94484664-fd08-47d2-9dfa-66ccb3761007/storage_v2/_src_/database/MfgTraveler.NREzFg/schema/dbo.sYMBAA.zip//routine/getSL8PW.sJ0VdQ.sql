-- =============================================
-- Author:		<Walker, Dominik>
-- Create date: <10/10/2017>
-- Description:	<Return records for SL8 Entry>
-- =============================================
CREATE PROCEDURE [dbo].[getSL8PW]
@StatList varchar(MAX)
AS
Declare @SN varchar(8) = (Select top 1 SerialNumber from SL8Records Where Complete = 0 and Process = 'PW' Order by DateTime ASC)

Select
s.SerialNumber,
s.Item,
c0.Description as Type,
p.Process as Operation,
p.Product,
u.Username,
Substring(
	(
		Select ','+p.PartNum as [text()]
From SL8Records a
Cross Apply dbo.Split(a.[Parts], ',') b
Inner join Parts p
on p.ID = b.items
Where a.SerialNumber = @SN
For xml path ('')
	), 2, 1000) [Parts],
s.Codes,
s.Rea_Notes,
s.Res_Notes,
s.blnkcol1,
s.blnkcol2,
s.blnkcol3,
c1.Description as Process,
c2.Description as Status,
c3.Description as Error,
s.DateTime,
s.ID
From SL8Records s

--Code_Refs Joins
Left join Code_Refs c0
on s.Type = c0.Code
Left join Code_Refs c1
on s.Process = c1.Code
Left join Code_Refs c2
on s.Status = c2.Code
Left join Code_Refs c3
on s.Error = c3.Code

--Join StatList
Inner join dbo.Split(@StatList, ',') b
on b.items = s.Status

--Other Joins
Inner join Processes p
on s.Operation = p.ID and s.Product = p.ID
Inner join Users u
on s.Operator = u.USERID

Where SerialNumber = @SN
and 
	 (Select s.DateTime 
	 from SL8Records s
	 Left join SL8Records s2 
	 on s.SerialNumber = s2.SerialNumber 
	 and s.DateTime < s2.DateTime
	 where s2.DateTime IS NULL
	 and s.SerialNumber = @SN)
	 <= Dateadd(minute, -5, Getdate())
and s.Process = 'PW'
and s.Complete = 0
Order by s.ID ASC


GO

