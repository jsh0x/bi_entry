-- =============================================
-- Author:		<Walker, Dominik>
-- Create date: <10/10/2017>
-- Description:	<Get possible routes when unit is failed>
-- =============================================
CREATE PROCEDURE [dbo].[getFailurePaths]
@Prod varchar(20), 
@Proc varchar(20)

AS

Select 
	p1.Process as [Routed To]
From Failure_Paths f
Inner join Processes p1
on f.Route_To = p1.ID
Where f.Cur_OP = 
	(Select ID 
	 from Processes
	 Where Process = @Proc
	 and Product = @Prod)

GO

