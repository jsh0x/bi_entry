-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getTravelLog]
	-- Add the parameters for the stored procedure here
	@startTime			DATETIME,
	@endTime				DATETIME,
	@preGlue			binary(1),
	@postGlue			binary(1),
	@fa					binary(1),
	@seid				INT


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
select l.timeStamp as TimeStamp,l.seid, type = case l.PreOrPostGlue when 'B' then 'Pre-Glue' when 'A' then 'Post-Glue' when 'F' then 'FA' else '?' end , 
l.comment,l.Summary as summary,l.GPS,L.WiFi,l.Proximity,l.strap,l.LED,l.TAEvents,l.intBat,l.versionpass,l.version 
from loc8prepostglue l 
WHERE  (@seid=0 OR @seid=l.seid) and timestamp BETWEEN @startTime and @endTime 
and

( (@preGlue=1 and l.PreOrPostGlue='B')
or (@postGlue=1 and l.PreOrPostGlue='A')
or (@fa=1 and l.PreOrPostGlue='F'))



END
GO
