CREATE TRIGGER [dbo].[updateCheckIn]
ON [dbo].[PuppetMaster]
FOR UPDATE 
AS 
BEGIN 
    IF NOT UPDATE(CheckIn) 
        UPDATE dbo.PuppetMaster SET CheckIn=GETDATE() 
        WHERE MachineName IN (SELECT MachineName FROM inserted) 
END
GO
