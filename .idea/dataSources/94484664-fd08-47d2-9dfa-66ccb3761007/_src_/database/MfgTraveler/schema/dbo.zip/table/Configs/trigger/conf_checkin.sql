Create TRIGGER conf_checkin
On Configs
For Update
As
Begin If not UPDATE(LastCheckIn)
	Update Configs Set LastCheckIn = GETDATE()
	WHERE MachineName IN (Select MachineName From inserted)
End
GO
