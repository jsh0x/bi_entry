-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[insertLOC8BeaconTest] 
	-- Add the parameters for the stored procedure here
	@serialID		INT,
    @timeStamp		datetime,
    @version		varchar(1),
    @motion			varchar(1),
    @signal	varchar(1),
	@beaconTemp		varchar(1),
    @altitude		varchar(1),
    @DQLine			varchar(1),
    @caseTamper		varchar(1),
	@power			varchar(1),
    @testTime		int,

    @motionState	varchar(5),
    @signalState	varchar(5),
    @powerState		varchar(5),
    @caseState		varchar(5),
    @versionState	varchar(5),
	@testType		varchar(1)



AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

INSERT INTO [dbo].[LOC8Beacon]
           ([serialID]
           ,[timeStamp]
           ,[version]
           ,[motion]
           ,[signalStrengh]
           ,[beaconTemp]
           ,[altitude]
           ,[DQLine]
           ,[caseTamper]
		   ,[power]
           ,[testTime]
           ,[motionState]
           ,[signalState]
           ,[powerState]
           ,[caseState]
           ,[versionState]
		   ,[testType])
     VALUES
           (
           @serialID,
           @timeStamp,
           @version, 
           @motion, 
           @signal, 
           @beaconTemp, 
           @altitude, 
           @DQLine, 
           @caseTamper, 
		   @power,
           @testTime, 
           @motionState, 
           @signalState, 
           @powerState, 
           @caseState, 
           @versionState,
		   @testType
		   )
END
GO
